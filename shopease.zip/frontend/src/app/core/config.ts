// Created by Harsh Chourasia
export const API = 'http://localhost:8080/api';
