// Created by Harsh Chourasia
package com.harsh.ecommerce.repository;

import com.harsh.ecommerce.entity.CartItem;
import com.harsh.ecommerce.entity.Product;
import com.harsh.ecommerce.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;
import java.util.Optional;

public interface CartItemRepository extends JpaRepository<CartItem, Long> {
    List<CartItem> findByUser(User user);
    Optional<CartItem> findByUserAndProduct(User user, Product product);
}
